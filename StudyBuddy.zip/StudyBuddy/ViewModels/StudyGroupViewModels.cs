using System.ComponentModel.DataAnnotations;
using StudyBuddy.Models;

namespace StudyBuddy.ViewModels;

public class StudyGroupFormViewModel
{
    public int Id { get; set; }

    [Required, StringLength(100)]
    public string Subject { get; set; } = string.Empty;

    [Required, StringLength(150)]
    [Display(Name = "Study topic")]
    public string Topic { get; set; } = string.Empty;

    [Required, DataType(DataType.DateTime)]
    [Display(Name = "Preferred schedule")]
    public DateTime Schedule { get; set; }

    [Required, StringLength(200)]
    public string Location { get; set; } = string.Empty;

    [Required, StringLength(1000)]
    public string Description { get; set; } = string.Empty;

    [Required, Range(2, 100, ErrorMessage = "Maximum members must be between 2 and 100.")]
    [Display(Name = "Maximum members")]
    public int MaxMembers { get; set; } = 5;
}

public class StudyGroupCardViewModel
{
    public int Id { get; set; }
    public string Subject { get; set; } = string.Empty;
    public string Topic { get; set; } = string.Empty;
    public DateTime Schedule { get; set; }
    public string Location { get; set; } = string.Empty;
    public string CreatorName { get; set; } = string.Empty;
    public int MemberCount { get; set; }
    public int MaxMembers { get; set; }
    public bool IsFull => MemberCount >= MaxMembers;
}

public class StudyGroupIndexViewModel
{
    public string? Subject { get; set; }
    public string? Search { get; set; }
    public List<string> Subjects { get; set; } = new();
    public List<StudyGroupCardViewModel> Groups { get; set; } = new();
}

public class StudyGroupDetailsViewModel
{
    public StudyGroup Group { get; set; } = null!;
    public bool IsMember { get; set; }
    public bool IsOwner { get; set; }
}

public class MyGroupsViewModel
{
    public List<StudyGroup> Created { get; set; } = new();
    public List<StudyGroup> Joined { get; set; } = new();
}

public class UpcomingSessionsViewModel
{
    public string Scope { get; set; } = "mine"; // "mine" or "all"
    public List<StudyGroup> Sessions { get; set; } = new();
}

public class AnnouncementCreateViewModel
{
    public int GroupId { get; set; }

    [Required, StringLength(500)]
    public string Message { get; set; } = string.Empty;
}

public class AdminUserRowViewModel
{
    public string Id { get; set; } = string.Empty;
    public string FullName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Course { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; }
    public int GroupsCreated { get; set; }
    public int Memberships { get; set; }
}
