using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudyBuddy.Data;
using StudyBuddy.Models;
using StudyBuddy.ViewModels;

namespace StudyBuddy.Controllers;

[Authorize]
public class AnnouncementsController : Controller
{
    private readonly ApplicationDbContext _db;
    private readonly UserManager<ApplicationUser> _userManager;

    public AnnouncementsController(ApplicationDbContext db, UserManager<ApplicationUser> userManager)
    {
        _db = db;
        _userManager = userManager;
    }

    // FR3.3: only the group creator can post announcements
    [HttpPost]
    public async Task<IActionResult> Create(AnnouncementCreateViewModel model)
    {
        var group = await _db.StudyGroups.AsNoTracking().FirstOrDefaultAsync(g => g.Id == model.GroupId);
        if (group is null) return NotFound();

        var userId = _userManager.GetUserId(User)!;
        if (group.CreatorId != userId) return Forbid();

        if (!ModelState.IsValid)
        {
            TempData["Error"] = "Announcement message is required (max 500 characters).";
            return RedirectToAction("Details", "StudyGroups", new { id = model.GroupId });
        }

        _db.Announcements.Add(new Announcement
        {
            GroupId = model.GroupId,
            UserId = userId,
            Message = model.Message.Trim()
        });
        await _db.SaveChangesAsync();

        TempData["Success"] = "Announcement posted.";
        return RedirectToAction("Details", "StudyGroups", new { id = model.GroupId });
    }
}
