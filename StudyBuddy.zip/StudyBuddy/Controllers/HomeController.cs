using Microsoft.AspNetCore.Mvc;

namespace StudyBuddy.Controllers;

public class HomeController : Controller
{
    public IActionResult Index() => View();

    public IActionResult Error() => View();
}
