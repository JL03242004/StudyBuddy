using System.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudyBuddy.Data;
using StudyBuddy.Models;
using StudyBuddy.ViewModels;

namespace StudyBuddy.Controllers;

[Authorize]
public class StudyGroupsController : Controller
{
    private readonly ApplicationDbContext _db;
    private readonly UserManager<ApplicationUser> _userManager;

    public StudyGroupsController(ApplicationDbContext db, UserManager<ApplicationUser> userManager)
    {
        _db = db;
        _userManager = userManager;
    }

    private string CurrentUserId => _userManager.GetUserId(User)!;

    // FR2.2 + FR2.3: list, search, filter by subject
    [AllowAnonymous]
    public async Task<IActionResult> Index(string? subject, string? search)
    {
        var query = _db.StudyGroups.AsNoTracking().AsQueryable();

        if (!string.IsNullOrWhiteSpace(subject))
            query = query.Where(g => g.Subject == subject);

        if (!string.IsNullOrWhiteSpace(search))
            query = query.Where(g => g.Subject.Contains(search) || g.Topic.Contains(search));

        var vm = new StudyGroupIndexViewModel
        {
            Subject = subject,
            Search = search,
            Subjects = await _db.StudyGroups.Select(g => g.Subject).Distinct().OrderBy(s => s).ToListAsync(),
            Groups = await query
                .OrderBy(g => g.Schedule)
                .Select(g => new StudyGroupCardViewModel
                {
                    Id = g.Id,
                    Subject = g.Subject,
                    Topic = g.Topic,
                    Schedule = g.Schedule,
                    Location = g.Location,
                    CreatorName = g.Creator!.FullName,
                    MemberCount = g.Members.Count,
                    MaxMembers = g.MaxMembers
                })
                .ToListAsync()
        };
        return View(vm);
    }

    // FR2.4 + FR3.2 + FR3.4: details, members, announcements
    public async Task<IActionResult> Details(int id)
    {
        var group = await _db.StudyGroups
            .AsSplitQuery()
            .Include(g => g.Creator)
            .Include(g => g.Members).ThenInclude(m => m.User)
            .Include(g => g.Announcements).ThenInclude(a => a.User)
            .FirstOrDefaultAsync(g => g.Id == id);

        if (group is null) return NotFound();

        var userId = CurrentUserId;
        return View(new StudyGroupDetailsViewModel
        {
            Group = group,
            IsOwner = group.CreatorId == userId,
            IsMember = group.Members.Any(m => m.UserId == userId)
        });
    }

    // FR2.1 Create
    [HttpGet]
    public IActionResult Create() =>
        View(new StudyGroupFormViewModel { Schedule = DateTime.Now.AddDays(1).Date.AddHours(15) });

    [HttpPost]
    public async Task<IActionResult> Create(StudyGroupFormViewModel model)
    {
        if (model.Schedule <= DateTime.Now)
            ModelState.AddModelError(nameof(model.Schedule), "The schedule must be in the future.");
        if (!ModelState.IsValid) return View(model);

        var userId = CurrentUserId;
        var group = new StudyGroup
        {
            Subject = model.Subject.Trim(),
            Topic = model.Topic.Trim(),
            Schedule = model.Schedule,
            Location = model.Location.Trim(),
            Description = model.Description.Trim(),
            MaxMembers = model.MaxMembers,
            CreatorId = userId
        };
        // the creator automatically becomes the first member (Owner)
        group.Members.Add(new GroupMember { UserId = userId, Role = "Owner" });

        _db.StudyGroups.Add(group);
        await _db.SaveChangesAsync();

        TempData["Success"] = "Study group created.";
        return RedirectToAction(nameof(Details), new { id = group.Id });
    }

    // FR2.7 Edit (creator only)
    [HttpGet]
    public async Task<IActionResult> Edit(int id)
    {
        var group = await _db.StudyGroups.AsNoTracking().FirstOrDefaultAsync(g => g.Id == id);
        if (group is null) return NotFound();
        if (group.CreatorId != CurrentUserId) return Forbid();

        return View(new StudyGroupFormViewModel
        {
            Id = group.Id,
            Subject = group.Subject,
            Topic = group.Topic,
            Schedule = group.Schedule,
            Location = group.Location,
            Description = group.Description,
            MaxMembers = group.MaxMembers
        });
    }

    [HttpPost]
    public async Task<IActionResult> Edit(int id, StudyGroupFormViewModel model)
    {
        var group = await _db.StudyGroups.Include(g => g.Members).FirstOrDefaultAsync(g => g.Id == id);
        if (group is null) return NotFound();
        if (group.CreatorId != CurrentUserId) return Forbid();

        if (model.MaxMembers < group.Members.Count)
            ModelState.AddModelError(nameof(model.MaxMembers),
                $"Maximum members cannot be lower than the current member count ({group.Members.Count}).");
        if (!ModelState.IsValid) return View(model);

        group.Subject = model.Subject.Trim();
        group.Topic = model.Topic.Trim();
        group.Schedule = model.Schedule;
        group.Location = model.Location.Trim();
        group.Description = model.Description.Trim();
        group.MaxMembers = model.MaxMembers;
        await _db.SaveChangesAsync();

        TempData["Success"] = "Study group updated.";
        return RedirectToAction(nameof(Details), new { id });
    }

    // FR2.7 Delete (creator only)
    [HttpGet]
    public async Task<IActionResult> Delete(int id)
    {
        var group = await _db.StudyGroups.AsNoTracking().FirstOrDefaultAsync(g => g.Id == id);
        if (group is null) return NotFound();
        if (group.CreatorId != CurrentUserId) return Forbid();
        return View(group);
    }

    [HttpPost, ActionName("Delete")]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var group = await _db.StudyGroups.FirstOrDefaultAsync(g => g.Id == id);
        if (group is null) return NotFound();
        if (group.CreatorId != CurrentUserId) return Forbid();

        _db.StudyGroups.Remove(group); // memberships + announcements cascade
        await _db.SaveChangesAsync();

        TempData["Success"] = "Study group deleted.";
        return RedirectToAction(nameof(MyGroups));
    }

    // FR2.5 Join (blocks full groups + duplicates)
    [HttpPost]
    public async Task<IActionResult> Join(int id)
    {
        var userId = CurrentUserId;

        // Serializable transaction so two users can't take the last slot at the same time
        await using var tx = await _db.Database.BeginTransactionAsync(IsolationLevel.Serializable);

        var group = await _db.StudyGroups.Include(g => g.Members).FirstOrDefaultAsync(g => g.Id == id);
        if (group is null) return NotFound();

        if (group.Members.Any(m => m.UserId == userId))
        {
            TempData["Error"] = "You are already a member of this group.";
            return RedirectToAction(nameof(Details), new { id });
        }
        if (group.Members.Count >= group.MaxMembers)
        {
            TempData["Error"] = "This group is already full.";
            return RedirectToAction(nameof(Details), new { id });
        }

        _db.GroupMembers.Add(new GroupMember { GroupId = id, UserId = userId, Role = "Member" });
        try
        {
            await _db.SaveChangesAsync();
            await tx.CommitAsync();
        }
        catch (DbUpdateException) // unique index (GroupId, UserId) violated
        {
            TempData["Error"] = "You are already a member of this group.";
            return RedirectToAction(nameof(Details), new { id });
        }

        TempData["Success"] = "You joined the group.";
        return RedirectToAction(nameof(Details), new { id });
    }

    // FR2.6 Leave
    [HttpPost]
    public async Task<IActionResult> Leave(int id)
    {
        var userId = CurrentUserId;
        var membership = await _db.GroupMembers.Include(m => m.Group)
            .FirstOrDefaultAsync(m => m.GroupId == id && m.UserId == userId);
        if (membership is null) return NotFound();

        if (membership.Group!.CreatorId == userId)
        {
            TempData["Error"] = "Group creators cannot leave their own group. Delete the group instead.";
            return RedirectToAction(nameof(Details), new { id });
        }

        _db.GroupMembers.Remove(membership);
        await _db.SaveChangesAsync();

        TempData["Success"] = "You left the group.";
        return RedirectToAction(nameof(MyGroups));
    }

    // FR2.8 My Groups
    public async Task<IActionResult> MyGroups()
    {
        var userId = CurrentUserId;
        var groups = await _db.StudyGroups
            .AsNoTracking()
            .Include(g => g.Members)
            .Include(g => g.Creator)
            .Where(g => g.Members.Any(m => m.UserId == userId))
            .OrderBy(g => g.Schedule)
            .ToListAsync();

        return View(new MyGroupsViewModel
        {
            Created = groups.Where(g => g.CreatorId == userId).ToList(),
            Joined = groups.Where(g => g.CreatorId != userId).ToList()
        });
    }
}
