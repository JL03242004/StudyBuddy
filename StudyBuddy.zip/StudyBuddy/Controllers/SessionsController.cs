using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudyBuddy.Data;
using StudyBuddy.Models;
using StudyBuddy.ViewModels;

namespace StudyBuddy.Controllers;

[Authorize]
public class SessionsController : Controller
{
    private readonly ApplicationDbContext _db;
    private readonly UserManager<ApplicationUser> _userManager;

    public SessionsController(ApplicationDbContext db, UserManager<ApplicationUser> userManager)
    {
        _db = db;
        _userManager = userManager;
    }

    // FR3.1: upcoming sessions based on group schedules
    public async Task<IActionResult> Upcoming(string scope = "mine")
    {
        var userId = _userManager.GetUserId(User)!;
        var now = DateTime.Now;

        var query = _db.StudyGroups.AsNoTracking()
            .Include(g => g.Members)
            .Where(g => g.Schedule >= now);

        if (scope != "all")
        {
            scope = "mine";
            query = query.Where(g => g.Members.Any(m => m.UserId == userId));
        }

        return View(new UpcomingSessionsViewModel
        {
            Scope = scope,
            Sessions = await query.OrderBy(g => g.Schedule).ToListAsync()
        });
    }
}
