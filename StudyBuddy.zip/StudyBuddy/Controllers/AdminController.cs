using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudyBuddy.Data;
using StudyBuddy.ViewModels;

namespace StudyBuddy.Controllers;

// FR4: optional administrator functions
[Authorize(Roles = DbSeeder.AdminRole)]
public class AdminController : Controller
{
    private readonly ApplicationDbContext _db;

    public AdminController(ApplicationDbContext db) => _db = db;

    // FR4.1 view registered users
    public async Task<IActionResult> Users()
    {
        var users = await _db.Users.AsNoTracking()
            .OrderBy(u => u.FullName)
            .Select(u => new AdminUserRowViewModel
            {
                Id = u.Id,
                FullName = u.FullName,
                Email = u.Email ?? string.Empty,
                Course = u.Course,
                CreatedAt = u.CreatedAt,
                GroupsCreated = u.CreatedGroups.Count,
                Memberships = u.Memberships.Count
            })
            .ToListAsync();
        return View(users);
    }

    // FR4.1 view study groups
    public async Task<IActionResult> Groups()
    {
        var groups = await _db.StudyGroups.AsNoTracking()
            .Include(g => g.Creator)
            .Include(g => g.Members)
            .OrderByDescending(g => g.CreatedAt)
            .ToListAsync();
        return View(groups);
    }

    // FR4.2 delete inappropriate groups
    [HttpPost]
    public async Task<IActionResult> DeleteGroup(int id)
    {
        var group = await _db.StudyGroups.FirstOrDefaultAsync(g => g.Id == id);
        if (group is null) return NotFound();

        _db.StudyGroups.Remove(group);
        await _db.SaveChangesAsync();

        TempData["Success"] = "Study group removed.";
        return RedirectToAction(nameof(Groups));
    }
}
