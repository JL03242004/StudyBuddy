using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Identity;

namespace StudyBuddy.Models;

/// <summary>Users table (extends IdentityUser: Id, Email, PasswordHash handled by Identity).</summary>
public class ApplicationUser : IdentityUser
{
    [Required, StringLength(100)]
    public string FullName { get; set; } = string.Empty;

    [Required, StringLength(100)]
    public string Course { get; set; } = string.Empty;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public ICollection<StudyGroup> CreatedGroups { get; set; } = new List<StudyGroup>();
    public ICollection<GroupMember> Memberships { get; set; } = new List<GroupMember>();
    public ICollection<Announcement> Announcements { get; set; } = new List<Announcement>();
}
