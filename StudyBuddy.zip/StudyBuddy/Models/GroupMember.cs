using System.ComponentModel.DataAnnotations;

namespace StudyBuddy.Models;

public class GroupMember
{
    public int Id { get; set; }

    public int GroupId { get; set; }
    public StudyGroup? Group { get; set; }

    [Required]
    public string UserId { get; set; } = string.Empty;
    public ApplicationUser? User { get; set; }

    public DateTime JoinedAt { get; set; } = DateTime.UtcNow;

    /// <summary>"Owner" or "Member".</summary>
    [Required, StringLength(20)]
    public string Role { get; set; } = "Member";
}
