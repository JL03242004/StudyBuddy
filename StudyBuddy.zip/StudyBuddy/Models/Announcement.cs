using System.ComponentModel.DataAnnotations;

namespace StudyBuddy.Models;

public class Announcement
{
    public int Id { get; set; }

    public int GroupId { get; set; }
    public StudyGroup? Group { get; set; }

    [Required]
    public string UserId { get; set; } = string.Empty;
    public ApplicationUser? User { get; set; }

    [Required, StringLength(500)]
    public string Message { get; set; } = string.Empty;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
