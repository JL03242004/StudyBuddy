using System.ComponentModel.DataAnnotations;

namespace StudyBuddy.Models;

public class StudyGroup
{
    public int Id { get; set; }

    [Required, StringLength(100)]
    public string Subject { get; set; } = string.Empty;

    [Required, StringLength(150)]
    public string Topic { get; set; } = string.Empty;

    /// <summary>Preferred study date and time (local time).</summary>
    [Required]
    public DateTime Schedule { get; set; }

    [Required, StringLength(200)]
    public string Location { get; set; } = string.Empty;

    [Required, StringLength(1000)]
    public string Description { get; set; } = string.Empty;

    [Range(2, 100)]
    public int MaxMembers { get; set; }

    [Required]
    public string CreatorId { get; set; } = string.Empty;
    public ApplicationUser? Creator { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public ICollection<GroupMember> Members { get; set; } = new List<GroupMember>();
    public ICollection<Announcement> Announcements { get; set; } = new List<Announcement>();

    public bool IsFull => Members.Count >= MaxMembers;
}
