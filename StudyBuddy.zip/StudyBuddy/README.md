# StudyBuddy (ASP.NET Core MVC, .NET 10)

## Run it
1. Open `StudyBuddy.csproj` in Visual Studio 2026 (File > Open > Project/Solution), then File > Save All to create a .sln.
2. Check the connection string in `appsettings.json` (default: SQL Server LocalDB).
3. Package Manager Console:
       Add-Migration InitialCreate
       Update-Database
4. Press F5. Default admin: admin@studybuddy.local / Admin#12345 (change it!).
